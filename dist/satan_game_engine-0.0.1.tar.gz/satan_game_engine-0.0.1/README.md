# SatanGameEngine

satan game engine is a pygame wrapper that makes creating games fast a lot easier by implementing functions that are often used and take time do write.
If you want to change functionality of SatanGameEngine just create new class that inhertits from SatanGameEngine.Engine.Game and define functions yourself.
