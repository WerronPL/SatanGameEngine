from SatanGameEngine.Engine import Game
from SatanGameEngine.Colors import *
from SatanGameEngine.GameObjects import Rect, Player, Background
